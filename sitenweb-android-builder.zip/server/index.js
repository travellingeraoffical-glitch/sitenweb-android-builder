const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const Busboy = require("busboy");
const { spawn } = require("child_process");
const { randomUUID } = require("crypto");

const PORT = Number(process.env.PORT || 8787);
const JOB_ROOT = path.resolve(process.env.JOB_ROOT || path.join(process.cwd(), "jobs"));
const MAX_UPLOAD_BYTES = Number(process.env.MAX_UPLOAD_BYTES || 524288000);
const BUILD_TIMEOUT_MS = Number(process.env.BUILD_TIMEOUT_MS || 900000);
const BUILD_API_TOKEN = process.env.BUILD_API_TOKEN || "";

fs.mkdirSync(JOB_ROOT, { recursive: true });

const jobs = new Map();

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Content-Length": Buffer.byteLength(body)
  });
  res.end(body);
}

function safeName(name) {
  return path.basename(name || "project.zip").replace(/[^a-zA-Z0-9._-]/g, "_");
}

function authorized(req) {
  if (!BUILD_API_TOKEN) return true;
  return req.headers.authorization === `Bearer ${BUILD_API_TOKEN}`;
}

function requireAuth(req, res) {
  if (authorized(req)) return true;
  json(res, 401, { error: "Unauthorized" });
  return false;
}

function parseUpload(req, jobDir) {
  return new Promise((resolve, reject) => {
    let total = 0;
    let found = false;
    let outputPath = null;

    const bb = Busboy({
      headers: req.headers,
      limits: { fileSize: MAX_UPLOAD_BYTES, files: 1 }
    });

    bb.on("file", (fieldname, file, info) => {
      if (fieldname !== "project") {
        file.resume();
        return;
      }

      found = true;
      outputPath = path.join(jobDir, `upload-${crypto.randomBytes(6).toString("hex")}.zip`);
      const out = fs.createWriteStream(outputPath);

      file.on("data", chunk => {
        total += chunk.length;
      });

      file.on("limit", () => {
        out.destroy();
        reject(new Error("Upload exceeds MAX_UPLOAD_BYTES"));
      });

      file.on("error", reject);
      out.on("error", reject);
      out.on("finish", () => {});

      file.pipe(out);
    });

    bb.on("error", reject);

    bb.on("finish", () => {
      if (!found) return reject(new Error('Missing multipart field "project"'));
      resolve(outputPath);
    });

    req.pipe(bb);
  });
}

function runBuild(job) {
  job.status = "building";
  job.startedAt = new Date().toISOString();

  const script = path.resolve(process.cwd(), "scripts", "build-android.sh");
  const jobDir = job.dir;

  const child = spawn("bash", [script, jobDir], {
    stdio: ["ignore", "pipe", "pipe"]
  });

  job.pid = child.pid;
  let logs = "";

  const append = data => {
    logs += data.toString();
    if (logs.length > 100000) logs = logs.slice(-100000);
    job.logs = logs;
  };

  child.stdout.on("data", append);
  child.stderr.on("data", append);

  const timer = setTimeout(() => {
    child.kill("SIGTERM");
    job.status = "failed";
    job.error = "Build timed out";
  }, BUILD_TIMEOUT_MS);

  child.on("error", err => {
    clearTimeout(timer);
    job.status = "failed";
    job.error = err.message;
    job.finishedAt = new Date().toISOString();
  });

  child.on("close", code => {
    clearTimeout(timer);
    if (job.status === "failed") return;

    if (code !== 0) {
      job.status = "failed";
      job.error = `Build exited with code ${code}`;
    } else {
      job.status = "completed";
    }

    job.finishedAt = new Date().toISOString();
  });
}

function findArtifact(dir, extension) {
  const root = path.join(dir, "output");
  if (!fs.existsSync(root)) return null;

  const stack = [root];
  while (stack.length) {
    const current = stack.pop();
    for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
      const p = path.join(current, entry.name);
      if (entry.isDirectory()) stack.push(p);
      else if (entry.isFile() && entry.name.toLowerCase().endsWith(extension)) return p;
    }
  }
  return null;
}

function sendFile(res, filePath, contentType) {
  if (!filePath || !fs.existsSync(filePath)) {
    json(res, 404, { error: "Artifact not found" });
    return;
  }

  const stat = fs.statSync(filePath);
  res.writeHead(200, {
    "Content-Type": contentType,
    "Content-Length": stat.size,
    "Content-Disposition": `attachment; filename="${path.basename(filePath)}"`
  });
  fs.createReadStream(filePath).pipe(res);
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "GET" && req.url === "/health") {
      return json(res, 200, { ok: true, service: "sitenweb-android-builder" });
    }

    if (req.method === "POST" && req.url === "/build") {
      if (!requireAuth(req, res)) return;

      const jobId = randomUUID();
      const dir = path.join(JOB_ROOT, jobId);
      fs.mkdirSync(dir, { recursive: true });

      const job = {
        id: jobId,
        status: "queued",
        createdAt: new Date().toISOString(),
        dir,
        logs: ""
      };

      jobs.set(jobId, job);

      try {
        await parseUpload(req, dir);
      } catch (err) {
        job.status = "failed";
        job.error = err.message;
        return json(res, 400, { jobId, status: job.status, error: job.error });
      }

      setImmediate(() => runBuild(job));
      return json(res, 202, { jobId, status: "queued" });
    }

    const match = req.url.match(/^\/build\/([^/]+)$/);
    if (req.method === "GET" && match) {
      const job = jobs.get(match[1]);
      if (!job) return json(res, 404, { error: "Job not found" });

      return json(res, 200, {
        jobId: job.id,
        status: job.status,
        createdAt: job.createdAt,
        startedAt: job.startedAt || null,
        finishedAt: job.finishedAt || null,
        error: job.error || null,
        logs: job.status === "failed" ? job.logs : undefined
      });
    }

    const artifact = req.url.match(/^\/build\/([^/]+)\/(apk|aab)$/);
    if (req.method === "GET" && artifact) {
      const job = jobs.get(artifact[1]);
      if (!job) return json(res, 404, { error: "Job not found" });
      if (job.status !== "completed") {
        return json(res, 409, { error: "Build is not completed", status: job.status });
      }

      const ext = artifact[2] === "apk" ? ".apk" : ".aab";
      const file = findArtifact(job.dir, ext);
      return sendFile(
        res,
        file,
        artifact[2] === "apk"
          ? "application/vnd.android.package-archive"
          : "application/octet-stream"
      );
    }

    json(res, 404, { error: "Not found" });
  } catch (err) {
    console.error(err);
    if (!res.headersSent) json(res, 500, { error: "Internal server error" });
  }
});

server.listen(PORT, () => {
  console.log(`SitenWeb Android Builder listening on http://localhost:${PORT}`);
});
