# SitenWeb Android Builder

A self-hosted build API for SitenWeb.

It accepts an Android project ZIP, runs Gradle inside a Docker container, and returns APK/AAB build artifacts.

## Architecture

SitenWeb -> POST /build -> Builder API -> Docker/Gradle -> APK + AAB

## Requirements

- Docker
- Node.js 20+
- An Android project that can be built with Gradle
- A machine/server with enough disk space and RAM for Android builds

The API itself does not require an external APK/AAB provider or external API key.

## Run

```bash
npm install
npm start
```

The API listens on:

```text
http://localhost:8787
```

For production, put the API behind HTTPS and configure authentication/rate limiting.

## Endpoints

### Health

```http
GET /health
```

### Create build

Send a multipart form with field `project`:

```bash
curl -X POST http://localhost:8787/build \
  -F "project=@my-android-project.zip"
```

Response:

```json
{
  "jobId": "example-id",
  "status": "queued"
}
```

### Check build

```http
GET /build/:jobId
```

### Download APK

```http
GET /build/:jobId/apk
```

### Download AAB

```http
GET /build/:jobId/aab
```

## Expected project

The uploaded ZIP should contain a normal Android/Gradle project.

The builder tries:

```text
./gradlew assembleRelease
./gradlew bundleRelease
```

If the project has a different Gradle setup, customize `scripts/build-android.sh`.

## Security

Do not expose this API publicly without protection.

Recommended production setup:

- HTTPS
- request authentication
- per-user build quotas
- maximum upload size
- build timeout
- isolated Docker containers
- automatic cleanup of old jobs
- non-root container execution where practical

Never put server secrets in the SitenWeb browser JavaScript.

## License

MIT
