#!/usr/bin/env bash
set -euo pipefail

JOB_DIR="${1:?job directory required}"
UPLOAD_ZIP="$(find "$JOB_DIR" -maxdepth 1 -type f -name 'upload-*.zip' | head -n 1)"

if [[ -z "$UPLOAD_ZIP" ]]; then
  echo "No uploaded ZIP found"
  exit 2
fi

SRC="$JOB_DIR/project"
OUTPUT="$JOB_DIR/output"

rm -rf "$SRC" "$OUTPUT"
mkdir -p "$SRC" "$OUTPUT"

echo "Extracting Android project..."
unzip -q "$UPLOAD_ZIP" -d "$SRC"

# Handle ZIPs that contain one top-level directory.
shopt -s dotglob
entries=("$SRC"/*)
if [[ ${#entries[@]} -eq 1 && -d "${entries[0]}" ]]; then
  INNER="${entries[0]}"
  TMP="$JOB_DIR/project-normalized"
  mv "$INNER" "$TMP"
  rm -rf "$SRC"
  mv "$TMP" "$SRC"
fi

if [[ ! -f "$SRC/gradlew" ]]; then
  echo "gradlew not found in uploaded project"
  exit 3
fi

chmod +x "$SRC/gradlew"

# Build inside an isolated Docker container.
# The image contains Android SDK + Gradle tooling.
IMAGE="${ANDROID_BUILDER_IMAGE:-ghcr.io/cirruslabs/android-sdk:latest}"

echo "Starting Android build container..."
docker run --rm \
  --network=none \
  --cpus="${BUILD_CPUS:-4}" \
  --memory="${BUILD_MEMORY:-6g}" \
  -v "$SRC:/workspace" \
  -v "$OUTPUT:/output" \
  -w /workspace \
  "$IMAGE" \
  bash -lc '
    set -euo pipefail

    if [[ -f ./gradlew ]]; then
      chmod +x ./gradlew
      ./gradlew --no-daemon assembleRelease bundleRelease
    else
      echo "Gradle wrapper missing"
      exit 4
    fi

    mkdir -p /output

    find . -type f \( -name "*.apk" -o -name "*.aab" \) \
      -not -path "*/build/intermediates/*" \
      -exec cp {} /output/ \;

    echo "Artifacts:"
    find /output -type f -maxdepth 1 -print
  '

echo "Build completed."
